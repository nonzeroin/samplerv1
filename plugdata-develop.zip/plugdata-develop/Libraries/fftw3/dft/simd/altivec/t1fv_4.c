/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-altivec.h"
#include "../common/t1fv_4.c"
